#!/usr/bin/env python3
from phonebridge.cli import main
if __name__ == "__main__":
    raise SystemExit(main())
