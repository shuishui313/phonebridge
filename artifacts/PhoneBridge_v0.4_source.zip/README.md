# PhoneBridge 0.4 — iPhone Agent 工具接口（独立原型）

> **交付状态（2026-11-10）**：可在 Linux / macOS 上运行的 Python **软件模拟 Phone Agent + stdio MCP Server**。附带受限的 `simctl` 诊断适配器和 Apple Simulator 的 SwiftUI/XCUITest 测试工程。**没有**实现真实 iPhone 上的任意跨 App 控制，**没有**实现真实微信发送，**没有**完成 Hark 真机集成或 Apple Simulator 实机测试。不要把 `mock` 理解成 Apple 官方 Simulator。

这是一个与任何单一模型解耦的手机操作接口，可让 Codex、支持 stdio MCP 的 Agent 客户端通过一致的工具协议调用。Hark 可以通过 SSH **间接操作已连接该 MCP 的 Codex 会话**，但本项目并不是 Hark 的内部插件，也不能获得 Hark 本机跨 App 权限。

## 能力说明

- 完全自主实现（未复制 Mika/Poki/Pinky 的源代码），附带用户上传的 v0.2 作为 `legacy_v02/` 比较参考。
- Python 3.11+，**运行核心和 MCP JSON-RPC stdio 不依赖第三方库**。
- 12 个 MCP 工具：连接状态、页面观察、打开 App、Home、Back、点击、滑动、输入文本、虚拟微信联系人、打开聊天、拟稿、执行已批准操作。
- 完整 Mock 微信工作流：输入命令 → 模拟进入联系人 → 精确定位联系人（同名要求消歧）→ 填入文本 → 生成待审批提案 → 独立 CLI 审批 → 一次性执行 → 检查**虚拟**消息记录。
- 默认**不允许**发送真实消息；Agent 可调用的 MCP 工具中没有批准动作；审批超时、状态变更即失效、重复执行拒绝、审核日志不记录消息正文。
- Mac `simctl` 诊断适配器只支持列举选定模拟器状态、启动 **PhoneBridge 测试 App**、保存截图。`simctl` 并不具备通用 `tap/swipe/type` 命令，此驱动明确拒绝这些动作。单独附带 SwiftUI + XCUITest 测试工程验证**测试 App 内**的点击和输入。

## 立即运行（Linux / macOS）

```bash
python3 -m unittest discover -s tests -v
python3 run_phonebridge.py serve
```

第二条命令启动 stdio MCP 服务，等待 MCP 客户端发送 JSON-RPC 请求。**不要把它当作普通交互 shell。** 若希望模拟发消息，请启用独立审批通道：

```bash
PB_DIR="$(mktemp -d /tmp/phonebridge.XXXXXX)"
chmod 700 "$PB_DIR"
python3 run_phonebridge.py --approval-socket "$PB_DIR/approval.sock" serve
```

在另一个**可信任的终端**里审批（批准前必须核对收件人、联系人 ID 和消息正文）：

```bash
python3 run_phonebridge.py --approval-socket "$PB_DIR/approval.sock" approvals list
python3 run_phonebridge.py --approval-socket "$PB_DIR/approval.sock" approvals approve '<审批 ID>'
# 或者拒绝：
python3 run_phonebridge.py --approval-socket "$PB_DIR/approval.sock" approvals deny '<审批 ID>'
```

实际 Agent 通过 `wechat_prepare_message` 获取审批 ID，确认后再由 Agent 调用 `phone_execute_operation`。模拟执行结果会返回 `real_message_sent: false`。

## 在 Codex / Hark 中使用

在存有本仓库的 Linux/Mac 主机上（**不是手机本机**）注册 MCP：

```bash
PB_ROOT="$(pwd)"
PB_PYTHON="$(command -v python3)"
PB_DIR="$(mktemp -d /tmp/phonebridge.XXXXXX)"
chmod 700 "$PB_DIR"
codex mcp add phonebridge -- "$PB_PYTHON" "$PB_ROOT/run_phonebridge.py" \
  --approval-socket "$PB_DIR/approval.sock" serve
```

然后打开一个**新的** Codex 会话，查看 `/mcp` 里的 `phonebridge`。在 Hark 里连接到运行 Codex 的同一台主机，使用该会话。Hark **尚未在本次环境中实测**，也没有证明可直接在本机 iPhone 操作微信。请见 [docs/hark-codex.md](docs/hark-codex.md)。

可以让 Codex 尝试：

> 使用 PhoneBridge 的模拟 iPhone，打开虚拟微信中的“小明”，输入“今天测试成功”，生成发送提案并等待我在独立终端审批。批准后只执行一次，并回读验证**虚拟消息**，请勿声称已经发送真实微信。

需要特别注意：如果 Agent 同时拥有完全的 shell 权限，且能读取同一操作系统用户的审批套接字，那么它**理论上也能自行批准**。这是演示级别的信任边界，不满足生产环境中的强独立审批。正式产品必须将审批放到 Agent 权限以外的独立服务/账户或可信移动端。参考 [docs/security.md](docs/security.md)。

## Apple 官方 Simulator（需要 Mac + Xcode）

```bash
./scripts/simctl-preflight.sh
# 选择实际 iPhone Simulator UDID：
./scripts/apple-simulator-test.sh '<SIMULATOR_UDID>'
```

脚本使用 `xcodegen` 生成 SwiftUI 测试项目，再运行 XCUITest 验证本项目的**测试 App**（不是微信）的 UI 点击、输入和展示结果。`xcodegen` 可通过 Homebrew 安装。详细说明在 [docs/apple-simulator.md](docs/apple-simulator.md)。本环境为 Linux，**上述 Xcode 测试没有运行过**。

可选的诊断 MCP 模式：

```bash
python3 run_phonebridge.py --driver simctl --sim-udid '<SIMULATOR_UDID>' serve
```

只提供 Simulator 状态、fixture 启动和截图；不会执行真实微信操作。完整 Apple Simulator UI 自动化调用需在 Mac 上开发与实测 XCUITest 通道。

## 文档

- [验收与测试报告](docs/test-report.md)
- [产品需求与阶段边界](docs/acceptance.md)
- [Hark / Codex 集成](docs/hark-codex.md)
- [Apple Simulator 实测手册](docs/apple-simulator.md)
- [安全和权限边界](docs/security.md)
- [面向 Codex 的开发约束](AGENTS.md)

## 目录结构

```text
phonebridge/          独立核心、模拟驱动、有限 simctl 诊断、MCP / CLI、审批通道
simulator/            SwiftUI 测试 App 和 XCUITest，用于官方 Simulator
scripts/              Apple Simulator 检查与测试脚本
tests/                Python 单元、并发安全、MCP 跨进程联调测试
legacy_v02/           用户上传的历史 v0.2 原型（不参与运行）
docs/                 Hark/Codex、测试、安全、后续真机验证说明
```

**GitHub 说明：**本 ZIP 是单独生成、已在本地跑过 Python 测试的 0.4 开发交付包。当前执行环境没有拿到 GitHub 写入凭证，也无法直接推送 `https://github.com/shuishui313/phonebridge`；请不要把本 ZIP 当作已经合并到仓库的版本。原仓库的 0.3 版与本包需要进行代码审查后再合并，不建议未经比较直接覆盖 `main`。
