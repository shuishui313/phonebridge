#!/usr/bin/env bash
set -euo pipefail
if [[ "$(uname -s)" != 'Darwin' ]]; then
  echo 'ERROR: Apple Simulator requires macOS with full Xcode.' >&2
  exit 2
fi
for cmd in xcodegen xcodebuild xcrun; do
  command -v "$cmd" >/dev/null || { echo "ERROR: missing $cmd" >&2; exit 2; }
done
xcrun --find simctl >/dev/null || { echo 'ERROR: full Xcode / simctl not selected' >&2; exit 2; }
if [[ $# -ne 1 ]]; then
  echo "Usage: $0 <booted-or-available-iPhone-simulator-UDID>" >&2
  xcrun simctl list devices available >&2
  exit 2
fi
UDID="$1"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$DIR/build"
xcodegen generate --spec "$DIR/simulator/project.yml" --project "$DIR/build/PhoneBridgeFixture.xcodeproj"
xcodebuild -version
xcrun simctl boot "$UDID" 2>/dev/null || true
xcrun simctl bootstatus "$UDID" -b
xcodebuild -project "$DIR/build/PhoneBridgeFixture.xcodeproj" \
  -scheme PhoneBridgeFixture \
  -destination "platform=iOS Simulator,id=$UDID" \
  -derivedDataPath "$DIR/build/DerivedData" \
  -resultBundlePath "$DIR/build/PhoneBridgeUITests.xcresult" \
  test
printf 'APPLE SIMULATOR XCTEST PASS: %s\n' "$UDID"
