# 用户目标与交付验收

## 终极产品目标

- **主交互入口 Hark**：在 Hark 对 Agent 说“打开微信，给测试联系人发一条指定消息”；尽量只验收结果，不逐项指挥。
- 优先 **iPhone（用户设备 iOS 27）**，Android 不在本期。
- 兼容 Codex、其他 MCP Agent；ChatGPT 原生工具支持另行核实。
- 统一的观察-规划-执行-结果验证链路；尽可能本机运行，避免将云服务器当作强制条件。
- 不复制 Mika/Poki/Pinky 的代码，也不以换名掩盖第三方代码使用。
- 发送真实消息之前要求收件人、正文的明确独立确认，允许取消。

## 分层验收标准

| 层级 | 验收内容 | 本包实测 |
|---|---|---|
| A — Mock | Python 测试、模拟微信、MCP stdio 子进程、多轮操作和外部审批 | **通过** |
| B — Apple Simulator | Xcode SwiftUI 测试 App 中 XCTest UI 点击/输入/阅读 | **未在 Mac 运行** |
| C — MCP 驱动 Apple Simulator | 同一服务实际观察+控制官方 Simulator 上的 App | **未实现完整触控通道** |
| D — Hark 联调 | iPhone Hark SSH → Codex → MCP → 执行器 | **未实测 Hark** |
| E — iOS 27 真机 | 在许可设备上完成所需第三方 App 交互 | **未实现/未实测** |

**今天可交付**：可复现运行的 0.4 软件原型、Mock 端到端测试、受限 simctl 诊断、XCTest 工程草稿和验收文档。

**不能承诺**：任意 iOS App（尤其微信）的跨 App 真机操作能力、一天内成品上线、Hark 内部插件能力。此限制来自 iOS 权限边界和当前不可访问 Mac/iPhone 的测试环境，而不是 Token 数量。
