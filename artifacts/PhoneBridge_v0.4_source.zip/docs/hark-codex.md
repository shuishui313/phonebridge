# Hark / Codex / PhoneBridge 集成路径

## 支持边界

```text
Hark (iPhone SSH 终端)
      | SSH
      v
Linux 或 macOS 主机：Codex CLI（用户使用 ChatGPT 账号登录）
      | stdio MCP / JSON-RPC
      v
PhoneBridge 守护进程
      |                \
      v                 v
模拟虚拟微信        Apple simctl 受限诊断（只适用于 macOS）
```

重要：Hark 主要负责 SSH，不意味着用户手机上的 Hark App 能读取其他 iOS App 的屏幕、点击微信，或向本机注入触控。手机、Codex、执行器可能在不同的设备上。`ChatGPT Plus` 账号授权与 `DeepSeek API Key` 是不同的模型入口，DeepSeek 并不是 PhoneBridge 的执行器。

## CLI 设置

从项目根目录：

```bash
PB_ROOT="$PWD" && PB_PYTHON="$(command -v python3)"
PB_DIR="$(mktemp -d /tmp/phonebridge.XXXXXX)" && chmod 700 "$PB_DIR"
codex mcp add phonebridge -- "$PB_PYTHON" "$PB_ROOT/run_phonebridge.py" --approval-socket "$PB_DIR/approval.sock" serve
```

使用 Codex 的 `/mcp` 检查 `phonebridge` 是否发现 12 个工具。之后通过 Hark 进入运行 Codex 的 SSH 主机，由同一个 Codex 配置调用工具。当前环境不能运行 Codex CLI 或 Hark 客户端，因此**这一步是配置说明，不是已通过的验收记录**。

独立终端上，用 `approvals list`、`approvals approve ID`，在每条消息真正虚拟发送前核对收件人 ID 和文本。审批套接字路径属于启动 MCP 服务的那台计算机，不属于 iPhone 本机。

## 扩展至其他 Agent

任何支持标准 stdio MCP 的客户端理论上都可以发现工具。兼容性仍需逐项实测。ChatGPT 消费者应用的自定义 MCP 写操作是否可用，取决于当前产品支持和账号权限，不能假定 Plus 与 Codex CLI 的功能相同。未来也可增加带认证的 Streamable HTTP 网关，但本版**没有对公网开放控制 API**。
