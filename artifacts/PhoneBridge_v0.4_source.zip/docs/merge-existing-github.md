# 将本包审查合并到用户的 GitHub 仓库

目标仓库：`https://github.com/shuishui313/phonebridge`

本包**没有直接克隆或修改远程仓库**，本次无法使用 GitHub push 凭证。远程公开 README 显示其已有 0.3 版、8 个 MCP 工具、18 项测试和与 Codex 的 MCP 验证；这些既有能力不应因覆盖而丢失。

建议在具备 GitHub 读写权限的 Codex/Work 环境里：

1. 克隆仓库、确认 branch `main`、运行现有 18 项测试并保存输出。
2. 新建 `feature/phonebridge-0.4`，对比两版 `phonebridge/`、`tests/`、`scripts/`，**按功能择优合并**。本包的 12 工具 stdio MCP、真实跨进程审批测试和受限 simctl 驱动是可迁移的候选实现；注意新旧工具名可能不一致，保留已有消费者兼容性。
3. 把 `simulator/` 与 `scripts/apple-simulator-test.sh` 引入测试分支，先在 Xcode Mac 主机上构建并运行 SwiftUI/XCUITest，再根据实际结果修复。
4. 不要将本包中 `legacy_v02/` 当作新的生产代码；历史文件可以不合并。
5. 在分支上运行 Python 与 Apple 测试，更新 `docs/test-report.md` 的实际证据，提出 Pull Request，通过审查后再合并。

禁止在没有现有代码差异分析的情况下执行 `git push --force`、`git reset --hard` 或覆盖 `main`。
