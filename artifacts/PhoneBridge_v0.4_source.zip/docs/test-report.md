# PhoneBridge 0.4 测试报告 — 2026-11-10

**环境**：Linux x86_64、Python 3.13.5；使用 Python `unittest`，没有 Apple Xcode / simctl / Codex CLI / Hark / iPhone 连接。

## 实际执行

```bash
python -m unittest discover -s tests -v
```

- **52/52 Python 测试通过**。包含严格参数校验、模拟 App/联系人、两位同名 Alex 的精确消歧、输入焦点、中文消息草稿、误收件人保护、外部审批/拒绝、审批 TTL、状态变更失效、重复执行拒绝、8 个并发执行竞争的仅一次成功、审计脱敏、Unix 套接字 0600 权限、MCP 初始化/工具发现/错误处理、跨进程 MCP JSON-RPC 与外部 CLI 审批联调。
- `tests/test_simctl.py` 的 8 项属于**fake subprocess 的驱动接口单元测试**，不是在 Mac 上调用真实 `xcrun`。
- `tests/test_subprocess.py` 真正启动了单独的 Python MCP stdio 服务进程，并在另一 Python 进程通过 Unix socket 审批，Agent 执行后从 Mock 微信历史读回结果。这是**实际进程通信**，仍然是**模拟手机**。

## 未验证项目

| 项目 | 状态 | 原因 |
|---|---|---|
| 第三方 MCP SDK 客户端直接兼容性 | 未验证 | 当前环境未安装 Codex/MCP SDK；本包自带 stdio MCP 协议实现 |
| Apple Simulator SwiftUI/XCUITest | 未运行 | Linux 环境无 Xcode / simctl |
| Apple Simulator 动态 MCP 点击/输入 | 未实现 | simctl 不提供通用触控命令，需要额外实时 XCTest bridge |
| Hark 实际端到端 | 未运行 | 当前没有用户设备/Hark 会话访问 |
| iOS 27 真机 | 未运行 | 当前没有真机设备连接，普通 iOS App 也受系统权限限制 |
| GitHub 远程 push | 未完成 | 当前环境无 GitHub 凭证且不能解析 github.com |

**结论**：已完成可运行的 Mock/MCP MVP 和受限 Mac Simulator 诊断代码。**未完成可控制微信真机的 Phone Agent 产品**。
