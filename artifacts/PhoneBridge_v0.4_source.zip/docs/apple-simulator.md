# Apple 官方 iOS Simulator 体验验证（待在 macOS 真正执行）

## 前置条件

- 一台有足够存储的 macOS 主机、完整 Xcode、至少一个 iPhone Simulator runtime。
- `xcrun --find simctl` 正常，`xcrun simctl list devices available` 能列出设备。
- `xcodegen` 用于生成本包所附 SwiftUI fixture 的 Xcode 工程。

```bash
./scripts/simctl-preflight.sh
./scripts/apple-simulator-test.sh '<iPhone 模拟器 UDID>'
```

成功标准：`xcodebuild test` 报告 2 个 `PhoneBridgeFixtureUITests` 测试通过（联系人的唯一 ID，打开“小明”输入 Hello PhoneBridge，点击 Send 后在**测试 App**出现该条消息）。保留 `.xcresult`、Xcode 版本、模拟器型号和 runtime 版本。

**本次交付没有在 macOS 上实际执行**，SwiftUI/XcodeGen 源码只经过静态阅读，不代表构建成功。Apple Simulator 并不能证明可以控制 iOS 27 真机上的真实微信。上面的测试应用模拟联系人和聊天，不联网、不访问第三方服务。

### 受限 simctl MCP Driver

`python3 run_phonebridge.py --driver simctl --sim-udid UDID serve` 使用 `xcrun simctl`：

- `phone_status` 列出真实 Simulator 状态；
- `phone_open_app(app="fixture")` 启动已安装的 fixture bundle `org.example.phonebridge.fixture`；
- `phone_inspect` 保存截图到受限权限的本地临时文件并返回哈希、路径；
- 点击、滑动、输入、打开微信、真实发送均返回 `unsupported_by_simctl` / `unsupported_app`，不伪装成功。

若要以 MCP 动态驱动测试 App 的 UI 点击，需要新增经 XCUITest 和 Mac 宿主通信的实时执行通道。下一阶段需在 Mac 上实测此连接，而不应仅靠 Mock 对话推断成功。
