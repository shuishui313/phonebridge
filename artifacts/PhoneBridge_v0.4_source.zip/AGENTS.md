# Codex / AI coding agent instructions for PhoneBridge

Work towards the product intent in `docs/acceptance.md`. Preserve originality and attribution. Never claim any Apple Simulator, Hark, or iPhone hardware test passed without actual logs from that environment. Mock is a Python in-memory fixture, not an Apple Simulator.

Before each code change: read README.md, inspect affected tests, use `python3 -m unittest discover -s tests -v` after changes. Never output API tokens or real private message contents. All real-message execution paths must remain blocked until an external approval mechanism outside the agent security boundary and a user-approved device interface are tested.

Prefer small, testable commits. Do not overwrite remote `main` or discard existing 0.3 code without reviewing the differences between 0.3 and this separately developed 0.4 package. When working on a Mac, use `scripts/simctl-preflight.sh` and `scripts/apple-simulator-test.sh <UDID>` to obtain real evidence. Always report test matrix: Mock / Apple Simulator / Codex / Hark / real iPhone separately.
