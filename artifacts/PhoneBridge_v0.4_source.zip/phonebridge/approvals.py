"""Operator-only approval Unix socket. It is deliberately not an MCP tool."""
from __future__ import annotations

import json
import os
import socket
import socketserver
import stat
import threading
from pathlib import Path
from typing import Any

from .core import PhoneBridge
from .drivers import fail


class _UnixServer(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads = True
    allow_reuse_address = False


class ApprovalEndpoint:
    def __init__(self, bridge: PhoneBridge, path: str):
        self.bridge = bridge
        self.path = Path(path)
        self._server = None
        self._thread = None

    def start(self):
        target = self.path
        if target.is_symlink() or os.path.lexists(target):
            raise FileExistsError(f"approval socket already exists: {target}")
        parent = target.parent
        parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        if stat.S_IMODE(parent.stat().st_mode) & 0o077:
            raise PermissionError("approval socket parent directory must not be group/world accessible (mode 0700)")
        bridge = self.bridge

        class Handler(socketserver.StreamRequestHandler):
            def handle(self):
                try:
                    line = self.rfile.readline(16_385)
                    if len(line) > 16_384:
                        reply = fail("request_too_large")
                    else:
                        request = json.loads(line)
                        op, item = request.get("action"), request.get("approval_id")
                        if op == "list":
                            reply = bridge.approval_list()
                        elif op == "approve" and isinstance(item, str):
                            reply = bridge.approve(item)
                        elif op == "deny" and isinstance(item, str):
                            reply = bridge.deny(item)
                        else:
                            reply = fail("unknown_approval_action")
                except (ValueError, AttributeError, TypeError):
                    reply = fail("invalid_approval_request")
                self.wfile.write((json.dumps(reply, ensure_ascii=False) + "\n").encode("utf-8"))

        self._server = _UnixServer(str(target), Handler)
        os.chmod(target, 0o600)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        return self

    def close(self):
        if self._server:
            self._server.shutdown()
            self._server.server_close()
            self._server = None
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None
        if self.path.exists() and stat.S_ISSOCK(self.path.lstat().st_mode):
            self.path.unlink()

    def __enter__(self):
        return self.start()

    def __exit__(self, *args):
        self.close()


def approval_request(path: str, action: str, approval_id: str | None = None, timeout: float = 5) -> dict[str, Any]:
    message = {"action": action}
    if approval_id:
        message["approval_id"] = approval_id
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as conn:
        conn.settimeout(timeout)
        conn.connect(path)
        conn.sendall((json.dumps(message) + "\n").encode())
        data = bytearray()
        while len(data) <= 1_000_000:
            part = conn.recv(4096)
            if not part:
                break
            data.extend(part)
            if b"\n" in part:
                break
    return json.loads(data)
