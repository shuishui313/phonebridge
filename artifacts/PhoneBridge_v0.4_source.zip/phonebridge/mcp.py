"""Small stdio MCP JSON-RPC host implemented without third-party dependencies.

Covers initialize, ping, tools/list, tools/call and initialized notification.
No claim of support for resources/prompts/sampling/HTTP transports.
"""
from __future__ import annotations

import json
import sys
from typing import Any, Callable

from .core import PhoneBridge
from .drivers import fail


PARAMS: dict[str, tuple[str, ...]] = {
    "phone_status": (),
    "phone_inspect": (),
    "phone_open_app": ("app",),
    "phone_home": (),
    "phone_back": (),
    "phone_tap": ("x", "y"),
    "phone_swipe": ("start_x", "start_y", "end_x", "end_y"),
    "phone_type_text": ("text",),
    "wechat_list_contacts": (),
    "wechat_open_chat": ("contact",),
    "wechat_prepare_message": ("recipient_id", "message"),
    "phone_execute_operation": ("approval_id",),
}

DESCRIPTIONS = {
    "phone_status": "Return device mode and capability disclosure. Do not assume a real phone is connected.",
    "phone_inspect": "Observe simulated screen / selected chat. On simctl, capture screenshot to a private local path.",
    "phone_open_app": "Open an allowlisted app. Mock: wechat/settings. Apple Simulator: fixture only.",
    "phone_home": "Go to mock home screen. Not supported by simctl backend.",
    "phone_back": "Back navigation on mock fixture only.",
    "phone_tap": "Tap normalized x/y in [0,1]. In mock these are fixed fixture hit targets, NOT real taps.",
    "phone_swipe": "Swipe using normalized coordinates. Not real iPhone control.",
    "phone_type_text": "Type into previously focused input. Never automatically presses Send.",
    "wechat_list_contacts": "List synthetic fixture contacts. Not real WeChat data.",
    "wechat_open_chat": "Open synthetic fixture contact by exact name or stable ID. Reject ambiguity.",
    "wechat_prepare_message": "Prepare virtual message; requires typed draft, current verified recipient. Must be approved through independent local CLI.",
    "phone_execute_operation": "Execute one approved virtual message exactly once. Cannot send a real iPhone message.",
}

NUMERIC = {"x", "y", "start_x", "start_y", "end_x", "end_y"}
SUPPORTED_VERSIONS = ("2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05")


def _tool_schema(name: str) -> dict:
    fields = PARAMS[name]
    properties = {f: {"type": "number" if f in NUMERIC else "string"} for f in fields}
    return {"name": name, "description": DESCRIPTIONS[name],
            "inputSchema": {"type": "object", "properties": properties, "required": list(fields), "additionalProperties": False}}


class MCPServer:
    def __init__(self, bridge: PhoneBridge):
        self.bridge = bridge
        self.initialized = False
        self.version = None

    def _call(self, name: str, args: dict) -> dict:
        if name not in PARAMS:
            return fail("unknown_tool")
        expected = set(PARAMS[name])
        if set(args) != expected:
            return fail("invalid_parameters", expected=sorted(expected))
        for key, value in args.items():
            if key in NUMERIC:
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    return fail("invalid_parameter_type", parameter=key)
            elif not isinstance(value, str):
                return fail("invalid_parameter_type", parameter=key)
        b = self.bridge
        table: dict[str, Callable] = {
            "phone_status": b.status, "phone_inspect": b.inspect,
            "phone_open_app": b.open_app, "phone_home": b.home, "phone_back": b.back,
            "phone_tap": b.tap, "phone_swipe": b.swipe, "phone_type_text": b.type_text,
            "wechat_list_contacts": b.list_contacts, "wechat_open_chat": b.open_chat,
            "wechat_prepare_message": b.prepare_message, "phone_execute_operation": b.execute,
        }
        return table[name](*[args[k] for k in PARAMS[name]])

    def process(self, data: dict) -> dict | None:
        if data.get("jsonrpc") != "2.0" or not isinstance(data.get("method"), str):
            return self._error(data.get("id"), -32600, "Invalid Request")
        method, request_id = data["method"], data.get("id")
        if "id" not in data:  # notifications MUST NOT receive a response
            if method == "notifications/initialized":
                self.initialized = True
            return None
        params = data.get("params", {})
        if not isinstance(params, dict):
            return self._error(request_id, -32602, "Invalid params")
        if method == "initialize":
            requested = params.get("protocolVersion")
            self.version = requested if requested in SUPPORTED_VERSIONS else "2025-06-18"
            result = {"protocolVersion": self.version, "capabilities": {"tools": {"listChanged": False}},
                      "serverInfo": {"name": "phonebridge", "version": "0.4.0"}}
        elif method == "ping":
            result = {}
        elif method == "tools/list":
            result = {"tools": [_tool_schema(x) for x in PARAMS]}
        elif method == "tools/call":
            if not isinstance(params.get("name"), str) or not isinstance(params.get("arguments", {}), dict):
                return self._error(request_id, -32602, "Invalid params")
            try:
                payload = self._call(params["name"], params.get("arguments", {}))
            except Exception:  # Don't disclose filesystem paths or secrets in protocol error.
                payload = fail("internal_tool_failure")
            result = {"content": [{"type": "text", "text": json.dumps(payload, ensure_ascii=False)}],
                      "structuredContent": payload, "isError": not payload.get("ok", False)}
        else:
            return self._error(request_id, -32601, "Method not found")
        return {"jsonrpc": "2.0", "id": request_id, "result": result}

    @staticmethod
    def _error(request_id, code, message):
        return {"jsonrpc": "2.0", "id": request_id, "error": {"code": code, "message": message}}

    def serve(self, stdin=None, stdout=None):
        source = stdin if stdin is not None else sys.stdin
        sink = stdout if stdout is not None else sys.stdout
        for line in source:
            if len(line) > 1_000_000:
                response = self._error(None, -32700, "Request too large")
            else:
                try:
                    response = self.process(json.loads(line))
                except (ValueError, AttributeError, TypeError):
                    response = self._error(None, -32700, "Parse error")
            if response is not None:
                sink.write(json.dumps(response, ensure_ascii=False, allow_nan=False) + "\n")
                sink.flush()
