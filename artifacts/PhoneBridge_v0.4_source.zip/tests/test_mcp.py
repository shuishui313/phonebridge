import io
import json
import unittest

from phonebridge.core import PhoneBridge
from phonebridge.mcp import MCPServer, PARAMS


class MCPTests(unittest.TestCase):
    def setUp(self):
        self.s = MCPServer(PhoneBridge())

    def call(self, name, **kw):
        r = self.s.process({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": name, "arguments": kw}})
        return r["result"]["structuredContent"]

    def test_initialize_protocol(self):
        r = self.s.process({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "tester", "version": "1"}}})
        self.assertEqual(r["result"]["protocolVersion"], "2025-06-18")

    def test_unknown_version_falls_back(self):
        r = self.s.process({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "future"}})
        self.assertEqual(r["result"]["protocolVersion"], "2025-06-18")

    def test_tools_list_schema(self):
        r = self.s.process({"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}})
        self.assertEqual({t["name"] for t in r["result"]["tools"]}, set(PARAMS))
        self.assertEqual(r["result"]["tools"][-1]["inputSchema"]["required"], ["approval_id"])

    def test_notification_no_reply(self):
        self.assertIsNone(self.s.process({"jsonrpc": "2.0", "method": "notifications/initialized"}))

    def test_unknown_method(self):
        self.assertEqual(self.s.process({"jsonrpc": "2.0", "id": 2, "method": "foo"})["error"]["code"], -32601)

    def test_ping(self):
        self.assertEqual(self.s.process({"jsonrpc": "2.0", "id": 3, "method": "ping"})["result"], {})

    def test_invalid_args(self):
        self.assertEqual(self.call("phone_tap", x="0.5", y=.5)["error"], "invalid_parameter_type")
        self.assertEqual(self.call("phone_tap", x=.5, y=.5, extra=1)["error"], "invalid_parameters")

    def test_unknown_tool(self):
        self.assertEqual(self.call("approval_approve", approval_id="notpossible")["error"], "unknown_tool")

    def test_tool_flow(self):
        self.assertTrue(self.call("phone_open_app", app="wechat")["ok"])
        self.assertEqual(self.call("wechat_open_chat", contact="小明")["contact"]["id"], "xiaoming-01")
        self.assertTrue(self.call("phone_tap", x=.5, y=.9)["ok"])
        self.assertTrue(self.call("phone_type_text", text="你好")["ok"])
        draft = self.call("wechat_prepare_message", recipient_id="xiaoming-01", message="你好")
        self.assertTrue(draft["ok"])
        self.assertEqual(self.call("phone_execute_operation", approval_id=draft["approval_id"])["error"], "independent_approval_required")

    def test_stream_responds_to_requests(self):
        src = io.StringIO(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "tools/list"}) + "\n" +
                          json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized"}) + "\n")
        out = io.StringIO()
        self.s.serve(src, out)
        self.assertEqual(len(out.getvalue().splitlines()), 1)

    def test_bad_json(self):
        out = io.StringIO()
        self.s.serve(io.StringIO("{bad}\n"), out)
        self.assertEqual(json.loads(out.getvalue())["error"]["code"], -32700)


if __name__ == "__main__": unittest.main()
