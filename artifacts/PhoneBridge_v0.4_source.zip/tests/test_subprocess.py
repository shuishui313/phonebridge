import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class SubprocessTests(unittest.TestCase):
    def test_jsonrpc_stdio_process_and_out_of_band_approval(self):
        with tempfile.TemporaryDirectory() as td:
            sock = str(Path(td)/"approval.sock")
            p = subprocess.Popen([sys.executable, "run_phonebridge.py", "--approval-socket", sock, "serve"],
                                 cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 encoding="utf-8", bufsize=1)
            try:
                for _ in range(150):
                    if Path(sock).exists(): break
                    time.sleep(.02)
                self.assertTrue(Path(sock).exists(), "approval socket not created")
                request_id = 0
                def query(method, params=None):
                    nonlocal request_id
                    request_id += 1
                    p.stdin.write(json.dumps({"jsonrpc": "2.0", "id": request_id,
                                              "method": method, "params": params or {}}, ensure_ascii=False) + "\n")
                    p.stdin.flush()
                    return json.loads(p.stdout.readline())
                init = query("initialize", {"protocolVersion": "2025-06-18"})
                self.assertEqual(init["result"]["serverInfo"]["name"], "phonebridge")
                names = {t["name"] for t in query("tools/list")["result"]["tools"]}
                self.assertIn("wechat_prepare_message", names)
                def tool(name, **args):
                    return query("tools/call", {"name": name, "arguments": args})["result"]["structuredContent"]
                tool("phone_open_app", app="wechat")
                tool("wechat_open_chat", contact="小明")
                tool("phone_tap", x=.5, y=.9)
                tool("phone_type_text", text="今天测试成功")
                op = tool("wechat_prepare_message", recipient_id="xiaoming-01", message="今天测试成功")["approval_id"]
                self.assertFalse(tool("phone_execute_operation", approval_id=op)["ok"])
                approve = subprocess.run([sys.executable, "run_phonebridge.py", "--approval-socket", sock,
                                          "approvals", "approve", op], cwd=ROOT, check=True, capture_output=True, text=True)
                self.assertTrue(json.loads(approve.stdout)["approved"])
                sent = tool("phone_execute_operation", approval_id=op)
                self.assertTrue(sent["virtual_message_added"])
                self.assertFalse(sent["real_message_sent"])
                self.assertEqual(tool("phone_inspect")["messages"][-1]["text"], "今天测试成功")
            finally:
                p.terminate()
                try: p.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    p.kill(); p.communicate(timeout=3)


if __name__ == "__main__": unittest.main()
